# Eine Überschrift der ersten Ordnung

## Eine Überschrift zweiter Ordnung

Ein Absatz mit *kursivem Text* , _auch kursiv_, **fetter Text**, __auch fett__, ***kursiv und fett***, ___alternative Schreibweise___.

* Ein Aufzählungspunkt
  - Kann auch ein Minuszeichen sein
  + Oder auch ein Pluszeichen
* Ein Link: [Markdown Syntax][1]

![Ein Bild](john-gruber.png)

Ein wenig Quellcode:
```js
var example = "dummy JavaScript code";
```

[1]: https://daringfireball.net/projects/markdown/syntax
