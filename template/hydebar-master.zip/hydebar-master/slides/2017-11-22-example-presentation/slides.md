## Example Presentation

-----

## Introduction

---

### A vertical slide

It is indicated by three dashes

-----

## The next horizontal slide

It is indicated by five dashes

---

### Again a vertical slide

- A reference-style link to a [Markdown cheatsheet][1]
- Another link to [GitHub-flavored Markdown][2]

[1]: https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet#links
[2]: https://help.github.com/categories/writing-on-github/

-----

## The End
### Questions?
