---
title: Hello World
subtitle: HydeBar, a Jekyll sidebar template with Reveal.js integration
categories: [general]
---

This is the first blog post. Edit or delete it - as you like :-)
