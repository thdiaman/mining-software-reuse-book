# HydeBar - Jekyll Sidebar Template

For all infos simply see the [online demo](https://ogobrecht.github.io/hydebar/), which exists as template, documentation and showcase.
