---
title: About
sidebar: 6
---

![Avatar]({{ site.data.authors[site.author].avatar }}){:.left.avatar} Hi, I am Ottmar Gobrecht, an Oracle Database developer living in Munich, Germany. [HydeBar][2] is a free time project with the focus on delivering a solid, customizable foundation without any hidden blackbox except [Jekyll][1] itself. It can run on GitHub Pages with an initial setup time less than 5 minutes. This is possible by forking the project, renaming the repository to yourUserName.github.io and setting up the url/baseurl in the `_config.yml` - see also the relevant section on the [features page]({{site.baseurl}}/features#quickstart-online-in-5-minutes).

> The whole site exists as template, documentation and showcase - you should delete the content above and place your own here ;-)

[1]: https://jekyllrb.com
[2]: https://github.com/ogobrecht/hydebar
